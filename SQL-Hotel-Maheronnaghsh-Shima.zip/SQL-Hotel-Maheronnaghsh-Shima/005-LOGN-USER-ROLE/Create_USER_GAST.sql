USE [FINAL_PROJEKT];
GO
CREATE USER [GAST] FOR LOGIN [GAST_LOGIN];
GO
--- Tabelle Abteilung ---
GRANT SELECT ON [dbo].[tb_Zimmer] TO [GAST]; -- alle Felder 
GO
GRANT SELECT ON [dbo].[tb_ZimmerTyp] TO [GAST]; -- alle Felder 
GO
GRANT SELECT ON  [dbo].[tb_Service]TO [GAST]; -- alle Felder 
GO