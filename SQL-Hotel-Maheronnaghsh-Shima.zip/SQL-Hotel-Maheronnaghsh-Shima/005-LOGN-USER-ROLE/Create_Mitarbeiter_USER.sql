USE [FINAL_PROJEKT];
GO
CREATE USER [Mitarbeiter_User] FOR LOGIN [Mitarbeiter_LOGIN];
GO
--- Tabelle Abteilung ---
GRANT SELECT ON [dbo].[tb_BuchungService] TO [Mitarbeiter_User]; -- alle Felder 
GO
GRANT SELECT ON  [dbo].[tb_Buchung] TO [Mitarbeiter_User]; -- alle Felder 
GO
GRANT SELECT ON [dbo].[tb_Gast] TO [Mitarbeiter_User]; -- alle Felder 
GO
GRANT SELECT ON [dbo].[tb_Rechnung] TO [Mitarbeiter_User]; -- alle Felder 
GO
GRANT SELECT ON  [dbo].[tb_Zahlung] TO [Mitarbeiter_User]; -- alle Felder 
GO
GRANT SELECT ON  [dbo].[tb_Service] TO [Mitarbeiter_User]; -- alle Felder 
GO
GRANT SELECT ON  [dbo].[tb_Zimmer]TO [Mitarbeiter_User]; -- alle Felder 
GO
GRANT SELECT ON  [dbo].[tb_ZimmerTyp] TO [Mitarbeiter_User]; -- alle Felder 
GO



-- UPDATE
GRANT UPDATE ON [dbo].[BuchungService] TO [Mitarbeiter_User]; -- alle Felder 
GO
GRANT UPDATE ON  [dbo].[tb_Buchung] TO [Mitarbeiter_User]; -- alle Felder 
GO
GRANT UPDATE ON [dbo].[tb_Gast] TO [Mitarbeiter_User]; -- alle Felder 
GO
GRANT UPDATE ON [dbo].[tb_Rechnung] TO [Mitarbeiter_User]; -- alle Felder 
GO
GRANT UPDATE ON  [dbo].[tb_Zahlung] TO [Mitarbeiter_User]; -- alle Felder 
GO

--- View View_FINALPROJEKT_Uebersicht ---
GRANT SELECT ON [dbo].[View_Gast_Service_Mitarbeiter] TO [Mitarbeiter_User]; -- alle Felder 
GO
GRANT SELECT ON  [dbo].[View_GesamtPreisVonService_GroupBy+Sum] TO [Mitarbeiter_User]; -- alle Felder 
GO
GRANT SELECT ON  [dbo].[View_GesamtPreisVonService_GroupByHaving+Sum] TO [Mitarbeiter_User]; -- alle Felder 
GO
-- Prozedure --
GRANT EXECUTE ON  [dbo].[sp_GastBuchung] TO [Mitarbeiter_User];
GO
----SkalarwertFunktionen
GRANT EXECUTE ON  [dbo].[sf_GesamtBetrageRechner]TO [Mitarbeiter_User];
GO
GRANT EXECUTE ON [dbo].[sf_IstZimmerFrei_in_Diesen_ZeitRaum ] TO [Mitarbeiter_User];
GO
-----TabellenwertFonktionen
GRANT SELECT ON [dbo].[dbo.tf_AnzahlBuchungenMitarbeiter] TO [Mitarbeiter_User];
GO
GRANT SELECT ON [dbo].[tf_BuchungenProGast] TO [Mitarbeiter_User];
GO




