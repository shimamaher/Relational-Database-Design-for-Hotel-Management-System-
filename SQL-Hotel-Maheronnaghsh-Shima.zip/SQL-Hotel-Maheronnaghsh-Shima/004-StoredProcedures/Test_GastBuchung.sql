USE [FINAL_PROJEKT];
GO

--Diese Procedure �berpr�ft alle Bedingungen die erf�llt sein m�ssen 
--damit ein Gast eine neue Buchung durchf�hren kann.und wenn ja dann erstellt sie die neue Buchung
 
DECLARE	@Erfolg bit; -- geklappt oder nicht
DECLARE	@Feedback NVARCHAR(MAX); -- Fehlermeldungen etc.

--OFFENE Rechnung
EXEC [dbo].[sp_GastBuchung]
'2026-01-01',
'2026-01-20',
4,
10,
@Erfolg OUTPUT,
@Feedback OUTPUT;

PRINT  @Erfolg;
PRINT @Feedback;
--CheckinDatum in Vergangenheit
--EXEC [dbo].[sp_GastBuchung]
--'2024.10.18',
--'2025.10.20',
--10,
--8,
-- @Erfolg OUTPUT,
--@Feedback OUTPUT;

--PRINT  @Erfolg;
--PRINT @Feedback;

--CheckoutDatum
--EXEC [dbo].[sp_GastBuchung]
--'2025.10.18',
--'2023.10.20',
--10,
--8,
-- @Erfolg OUTPUT,
--@Feedback OUTPUT;

--PRINT  @Erfolg;
--PRINT @Feedback;
--Zimmer Belegt
--EXEC [dbo].[sp_GastBuchung]
--'2025-10-18',
--'2025-10-20',
--10,
--8,
-- @Erfolg OUTPUT,
--@Feedback OUTPUT;

--PRINT  @Erfolg;
--PRINT @Feedback;
--neue Buchung
--EXEC [dbo].[sp_GastBuchung]
--'2025-10-18',
--'2025-10-20',
--1,
--8,
-- @Erfolg OUTPUT,
--@Feedback OUTPUT;