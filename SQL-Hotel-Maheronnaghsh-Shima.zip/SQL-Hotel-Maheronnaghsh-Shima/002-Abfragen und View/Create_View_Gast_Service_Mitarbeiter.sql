USE [FINAL_PROJEKT]
GO

/****** Object:  View [dbo].[View_Gast_Service_Mitarbeiter]    Script Date: 18.09.2025 10:47:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[View_Gast_Service_Mitarbeiter]
AS
SELECT        dbo.tb_Person.Nachname, dbo.tb_Person.Vorname, dbo.tb_Buchung.BuchungID, dbo.tb_Service.Service, tb_Person_1.Nachname AS [M.Nachname], tb_Person_1.Vorname AS [M.Vorname], dbo.BuchungService.Anzahl, 
                         dbo.BuchungService.Datum
FROM            dbo.BuchungService INNER JOIN
                         dbo.tb_Buchung ON dbo.BuchungService.BuchungID = dbo.tb_Buchung.BuchungID INNER JOIN
                         dbo.tb_Gast ON dbo.tb_Buchung.GastID = dbo.tb_Gast.GastID INNER JOIN
                         dbo.tb_Mitarbeiter ON dbo.BuchungService.MitarbeiterID = dbo.tb_Mitarbeiter.MitarbeiterID INNER JOIN
                         dbo.tb_Service ON dbo.BuchungService.ServiceID = dbo.tb_Service.ServiceID INNER JOIN
                         dbo.tb_Person ON dbo.tb_Gast.PersonID = dbo.tb_Person.PersonID INNER JOIN
                         dbo.tb_Person AS tb_Person_1 ON dbo.tb_Mitarbeiter.PersonID = tb_Person_1.PersonID
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "BuchungService"
            Begin Extent = 
               Top = 13
               Left = 254
               Bottom = 175
               Right = 439
            End
            DisplayFlags = 280
            TopColumn = 1
         End
         Begin Table = "tb_Buchung"
            Begin Extent = 
               Top = 3
               Left = 542
               Bottom = 133
               Right = 718
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "tb_Gast"
            Begin Extent = 
               Top = 17
               Left = 872
               Bottom = 113
               Right = 1039
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "tb_Mitarbeiter"
            Begin Extent = 
               Top = 181
               Left = 550
               Bottom = 303
               Right = 717
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "tb_Service"
            Begin Extent = 
               Top = 192
               Left = 6
               Bottom = 305
               Right = 173
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "tb_Person"
            Begin Extent = 
               Top = 4
               Left = 1254
               Bottom = 134
               Right = 1421
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "tb_Person_1"
            Begin Extent = 
               Top = 195
               Left = 876
               Bottom = 325
               Right = 1043
            End
  ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'View_Gast_Service_Mitarbeiter'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane2', @value=N'          DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'View_Gast_Service_Mitarbeiter'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=2 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'View_Gast_Service_Mitarbeiter'
GO


