USE [FINAL_PROJEKT]
GO

/****** Object:  View [dbo].[View_FullJoin_Gast_ohne_ServiceBuchung]    Script Date: 18.09.2025 13:59:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[View_FullJoin_Gast_ohne_ServiceBuchung]
AS
SELECT        dbo.tb_Person.Nachname, dbo.tb_Person.Vorname, dbo.tb_Buchung.BuchungID, dbo.tb_Service.Service
FROM            dbo.tb_Service INNER JOIN
                         dbo.BuchungService ON dbo.tb_Service.ServiceID = dbo.BuchungService.ServiceID FULL OUTER JOIN
                         dbo.tb_Gast INNER JOIN
                         dbo.tb_Buchung ON dbo.tb_Gast.GastID = dbo.tb_Buchung.GastID INNER JOIN
                         dbo.tb_Person ON dbo.tb_Gast.PersonID = dbo.tb_Person.PersonID ON dbo.BuchungService.BuchungID = dbo.tb_Buchung.BuchungID
WHERE        (dbo.tb_Service.Service IS NULL)
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[41] 4[14] 2[16] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "BuchungService"
            Begin Extent = 
               Top = 138
               Left = 999
               Bottom = 268
               Right = 1184
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "tb_Buchung"
            Begin Extent = 
               Top = 27
               Left = 704
               Bottom = 157
               Right = 880
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "tb_Gast"
            Begin Extent = 
               Top = 21
               Left = 414
               Bottom = 117
               Right = 581
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "tb_Person"
            Begin Extent = 
               Top = 125
               Left = 83
               Bottom = 255
               Right = 250
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "tb_Service"
            Begin Extent = 
               Top = 200
               Left = 1261
               Bottom = 313
               Right = 1428
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'View_FullJoin_Gast_ohne_ServiceBuchung'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane2', @value=N'Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'View_FullJoin_Gast_ohne_ServiceBuchung'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=2 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'View_FullJoin_Gast_ohne_ServiceBuchung'
GO


