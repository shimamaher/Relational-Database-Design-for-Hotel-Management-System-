--Diese Funktion pr�ft ob ein bestimmtes ZimmerID in einem angegebenen Zeitraum frei ist oder belegt 
-- 0 ist f�r frei
-- 1 ist f�r belegt
PRINT([dbo].[sf_IstZimmerFrei_in_Diesen_ZeitRaum ](1,'2025.12.12','2025.12.30'))
PRINT([dbo].[sf_IstZimmerFrei_in_Diesen_ZeitRaum ](8,'2025.12.12','2025.12.30'))