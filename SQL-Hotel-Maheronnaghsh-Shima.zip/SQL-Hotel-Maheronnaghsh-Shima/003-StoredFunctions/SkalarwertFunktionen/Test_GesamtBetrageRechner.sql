

--Diese Funktion berechnet f�r eine gegebene BuchungID den Gesamtbetrag
--Im Ergebnis sind sowohl die Kosten f�r die �bernachtungen
--als auch die zus�tzlich gebuchten Services enthalten
Print([dbo].[sf_GesamtBetrageRechner](2))
Print([dbo].[sf_GesamtBetrageRechner](3))
