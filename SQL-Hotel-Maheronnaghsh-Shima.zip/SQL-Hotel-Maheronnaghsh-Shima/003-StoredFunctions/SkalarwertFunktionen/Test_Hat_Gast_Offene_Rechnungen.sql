

--0 -->Keine offene Rechnungen
--1-->Offene Rechnungen
Print([dbo].[sf_Hat_Gast_Offene_Rechnungen](3))
Print([dbo].[sf_Hat_Gast_Offene_Rechnungen](2))
