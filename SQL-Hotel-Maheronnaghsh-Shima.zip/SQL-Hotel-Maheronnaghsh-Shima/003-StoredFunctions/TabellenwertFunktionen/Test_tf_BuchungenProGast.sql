--Diese Funktion liefert f�r eine gegebene GastID
--alle Buchungen, die dieser Gast bereits bei uns gemacht hat.
SELECT *
FROM [dbo].[tf_BuchungenProGast](1)
ORDER BY CheckinDatum;
--Gast 27 Hat noch keine Buchung gemacht
SELECT *
FROM [dbo].[tf_BuchungenProGast](27)
ORDER BY CheckinDatum;