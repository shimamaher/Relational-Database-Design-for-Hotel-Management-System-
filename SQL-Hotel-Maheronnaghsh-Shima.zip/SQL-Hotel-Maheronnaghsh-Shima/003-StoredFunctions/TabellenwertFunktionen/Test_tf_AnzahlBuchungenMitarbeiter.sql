
--Diese Funktion gibt Mitarbeiterdaten und  die Anzahl der Services zur�ck,
--f�r die er(3) zust�ndig war.
SELECT *
FROM  [dbo].[dbo.tf_AnzahlBuchungenMitarbeiter](3)
--Diese Funktion gibt Mitarbeiterdaten und  die Anzahl der Services zur�ck,
--f�r die er(11) zust�ndig war.
SELECT *
FROM  [dbo].[dbo.tf_AnzahlBuchungenMitarbeiter](11)