-- alle Mitarbeiter speichern --
SELECT DISTINCT [Mitarbeiter]
INTO [tb_Mitarbeiter_Import]
  FROM [dbo].[tb_RohDaten] ;
  
-- Prim�rschlussel, ID, Index --------------
-- neue Spalte ----
ALTER TABLE [tb_Mitarbeiter_Import]
ADD [MitarbeiterID] [int] IDENTITY(1,1) NOT NULL;
GO