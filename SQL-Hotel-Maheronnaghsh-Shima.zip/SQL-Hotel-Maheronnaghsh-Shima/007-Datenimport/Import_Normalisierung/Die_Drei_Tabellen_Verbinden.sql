USE [FINAL_PROJEKT];
GO

-- tb_Mitarbeiter_Import und [tb_Mitarbeiter_Rollen_import] --

ALTER TABLE  [dbo].[tb_Mitarbeiter_Rollen_import]
WITH CHECK 
ADD CONSTRAINT [FK_tb_Mitarbeiter_Rollen_import_tb_Mitarbeiter_Import] FOREIGN KEY([MitarbeiterID])
REFERENCES [dbo].[tb_Mitarbeiter_Import] ([MitarbeiterID]);
GO

ALTER TABLE  [dbo].[tb_Mitarbeiter_Rollen_import]
CHECK CONSTRAINT [FK_tb_Mitarbeiter_Rollen_import_tb_Mitarbeiter_Import];
GO

------------------------------------------------------------------

 --[tb_Mitarbeiter_Rollen_import] und [dbo].[tb_Rolle_Import] --
ALTER TABLE [dbo].[tb_Mitarbeiter_Rollen_import]  
WITH CHECK 
ADD CONSTRAINT [FK_tb_Mitarbeiter_Rollen_import_tb_Rolle_Import] FOREIGN KEY([RolleID])
REFERENCES  [dbo].[tb_Rolle_Import]([RolleID]);
GO

ALTER TABLE [dbo].[tb_Mitarbeiter_Rollen_import] 
CHECK CONSTRAINT [FK_tb_Mitarbeiter_Rollen_import_tb_Rolle_Import];
GO