-- alle Rollen speichern --
SELECT DISTINCT [Rolle]
INTO [tb_Rolle_Import]
  FROM [dbo].[tb_RohDaten] ;
  
-- Prim�rschlussel, ID, Index --------------
-- neue Spalte ----
ALTER TABLE [tb_Rolle_Import]
ADD [RolleID] [int] IDENTITY(1,1) NOT NULL;
GO