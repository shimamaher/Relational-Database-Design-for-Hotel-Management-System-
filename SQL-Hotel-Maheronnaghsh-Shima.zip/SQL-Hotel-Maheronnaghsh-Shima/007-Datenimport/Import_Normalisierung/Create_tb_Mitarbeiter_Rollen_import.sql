SELECT  [dbo].[tb_Mitarbeiter_Import].[MitarbeiterID],[dbo].[tb_Rolle_Import].[RolleID]
	 INTO [tb_Mitarbeiter_Rollen_import] -- -- neue m:n Tabelle
FROM [dbo].[tb_Mitarbeiter_Import]
	   INNER JOIN [dbo].[tb_RohDaten]
			ON [dbo].[tb_Mitarbeiter_Import].[Mitarbeiter]=[dbo].[tb_RohDaten].[Mitarbeiter]
	   INNER JOIN [dbo].[tb_Rolle_Import]
			ON [dbo].[tb_RohDaten].[Rolle] = [dbo].[tb_Rolle_Import].[Rolle] ;