--Buchung nummer 118 und die Rechnung dazu  wird gel�scht
DELETE FROM [dbo].[tb_Buchung]
WHERE [BuchungID]=118;