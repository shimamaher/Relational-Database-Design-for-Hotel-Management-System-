USE [FINAL_PROJEKT]
GO
/****** Object:  Trigger [dbo].[trg_Rechnung_Erstellen]    Script Date: 17.09.2025 15:07:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--Trigger dder nach jedem INSERT in die tb_Buchung automatisch eine 
--neue Rechnung in tb_Rechnung erstellt


 CREATE OR  ALTER       TRIGGER [dbo].[trg_Nach_Neuer_Buchung_Erstellt_Neue_Rechnung]
ON [dbo].[tb_Buchung]
AFTER INSERT
AS BEGIN
SET NOCOUNT ON;
	DECLARE @msg AS nvarchar(MAX);
INSERT INTO [dbo].[tb_Rechnung]([Datum],[GesamtBetrag],[BuchungID])
SELECT CheckinDatum,[dbo].[sf_GesamtBetrageRechner](BuchungID),BuchungID
FROM inserted;





	END;