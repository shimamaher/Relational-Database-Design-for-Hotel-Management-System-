--Zimmer wird geandert fur Buchung 118
UPDATE [dbo].[tb_Buchung]
SET [ZimmerID]=19
WHERE [BuchungID] = 118; 