--Das Datum der neuen ServiceBuchung liegt nicht innerhalb checkin und checkout Datum
INSERT INTO [dbo].[BuchungService]([BuchungID],[ServiceID],[Anzahl],[MitarbeiterID],[Datum])VALUES(1,1,1,4,'2026.01.01');
--Das Datum der neuen ServiceBuchung liegt innerhalb checkin Datum und checkout Datum
INSERT INTO [dbo].[BuchungService]([BuchungID],[ServiceID],[Anzahl],[MitarbeiterID],[Datum])VALUES(122,1,1,4,'2026.02.09');