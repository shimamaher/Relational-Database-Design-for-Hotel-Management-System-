

--RechnungStatus wird von offen in bezahlt umgewandelt
UPDATE [dbo].[tb_Rechnung]
SET [RechnungStatus]='bezahlt'
WHERE [RechnungID] = 10; 


--Es wird ein Rabatt von 10% f�r die Rechnung 4 gew�hrt
DECLARE @a int;
SET @a=(SELECT   [GesamtBetrag] FROM [dbo].[tb_Rechnung]WHERE [RechnungID]=4);
UPDATE [dbo].[tb_Rechnung]
SET [GesamtBetrag]=@a*0.9
WHERE [RechnungID] = 4; 