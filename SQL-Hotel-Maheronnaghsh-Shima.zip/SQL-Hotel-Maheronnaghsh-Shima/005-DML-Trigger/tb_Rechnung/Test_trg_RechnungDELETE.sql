

--Rechnung nummer 10 wird gel�scht
DELETE FROM [dbo].[tb_Rechnung]
WHERE [RechnungID]=10;