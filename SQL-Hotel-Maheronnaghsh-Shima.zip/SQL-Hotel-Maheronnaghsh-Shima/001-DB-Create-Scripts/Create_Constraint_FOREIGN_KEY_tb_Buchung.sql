USE [FINAL_PROJEKT]
/****** Object:  Table [dbo].[tb_Buchung]    Script Date: 17.09.2025 08:53:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tb_Buchung](
	[BuchungID] [int] IDENTITY(1,1) NOT NULL,
	[CheckinDatum] [date] NOT NULL,
	[CheckoutDatum] [date] NOT NULL,
	[GastID] [int] NOT NULL,
	[ZimmerID] [int] NOT NULL,
 CONSTRAINT [PK_tb_Buchung] PRIMARY KEY CLUSTERED 
(
	[BuchungID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
---Standardwerte
ALTER TABLE [dbo].[tb_Buchung] ADD  CONSTRAINT [DF_tb_Buchung_CheckinDatum]  DEFAULT (getdate()) FOR [CheckinDatum]
GO
----Foreign Key
ALTER TABLE [dbo].[tb_Buchung]  WITH CHECK ADD  CONSTRAINT [FK_tb_Buchung_tb_Gast] FOREIGN KEY([GastID])
REFERENCES [dbo].[tb_Gast] ([GastID])
GO

ALTER TABLE [dbo].[tb_Buchung] CHECK CONSTRAINT [FK_tb_Buchung_tb_Gast]
GO

ALTER TABLE [dbo].[tb_Buchung]  WITH CHECK ADD  CONSTRAINT [FK_tb_Buchung_tb_Zimmer] FOREIGN KEY([ZimmerID])
REFERENCES [dbo].[tb_Zimmer] ([ZimmerID])
GO

ALTER TABLE [dbo].[tb_Buchung] CHECK CONSTRAINT [FK_tb_Buchung_tb_Zimmer]
GO